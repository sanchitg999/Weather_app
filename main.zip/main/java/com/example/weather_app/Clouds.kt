package com.example.weather_app

data class Clouds(
    val all: Int
)