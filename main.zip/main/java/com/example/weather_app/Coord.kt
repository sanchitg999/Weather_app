package com.example.weather_app

data class Coord(
    val lat: Double,
    val lon: Double
)