package com.example.weather_app

data class Wind(
    val deg: Int,
    val gust: Double,
    val speed: Double
)